package com.example.musikai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
