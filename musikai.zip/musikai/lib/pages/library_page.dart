// lib/pages/library_page.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../services/player_manager.dart';

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  List<Track> downloaded = [];

  @override
  void initState() {
    super.initState();
    _loadDownloads();
  }

  Future<void> _loadDownloads() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString('downloaded_tracks') ?? '[]';
    final arr = json.decode(raw) as List;
    setState(() {
      downloaded = arr.map((e) => Track.fromJson(e as Map<String, dynamic>)).toList();
    });
  }

  Future<void> _saveDownloads() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('downloaded_tracks', json.encode(downloaded.map((t) => t.toJson()).toList()));
  }

  Future<void> _downloadTrack(Track t) async {
    final dir = await getApplicationDocumentsDirectory();
    final fileName = '${t.id}.mp3';
    final file = File('${dir.path}/$fileName');
    if (await file.exists()) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Already downloaded')));
      return;
    }
    final res = await http.get(Uri.parse(t.source));
    if (res.statusCode == 200) {
      await file.writeAsBytes(res.bodyBytes);
      final local = Track(id: t.id, title: t.title, artist: t.artist, image: t.image, source: file.path, isLocal: true);
      setState(() => downloaded.add(local));
      await _saveDownloads();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Downloaded ${t.title}')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Download failed')));
    }
  }

  Widget section(String title, List<Track> list, PlayerManager pm) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text('No tracks yet', style: TextStyle(color: Colors.grey)),
          ),
        ...list.map((t) => ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: Image.network(t.image, width: 48, height: 48, fit: BoxFit.cover),
              ),
              title: Text(t.title),
              subtitle: Text(t.artist),
              trailing: IconButton(
                icon: const Icon(Icons.play_arrow),
                onPressed: () => pm.playTrackDirect(t),
              ),
            )),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context);
    final onlineSamples = List.generate(8, (i) {
      final idx = i + 1;
      return Track(
        id: 'online$idx',
        title: 'Downloadable Song $idx',
        artist: 'Artist $idx',
        image: 'https://picsum.photos/seed/down$idx/300/300',
        source: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(idx % 16) + 1}.mp3',
        isLocal: false,
      );
    });

    return Scaffold(
      // removed AppBar title per request
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          children: [
            // ✅ Favorites section added here
            section('Favorites', pm.favorites, pm),
            const Divider(),

            const Text('Downloaded', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (downloaded.isEmpty) const Text('No downloads yet.'),
            ...downloaded.map((t) => ListTile(
                  leading: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Image.network(t.image, width: 48, height: 48, fit: BoxFit.cover)),
                  title: Text(t.title),
                  subtitle: Text(t.artist),
                  trailing: IconButton(icon: const Icon(Icons.play_arrow), onPressed: () => pm.playTrackDirect(t)),
                )),
            const Divider(),
            const SizedBox(height: 6),
            const Text('Available for download', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...onlineSamples.map((t) => ListTile(
                  leading: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Image.network(t.image, width: 48, height: 48, fit: BoxFit.cover)),
                  title: Text(t.title),
                  subtitle: Text(t.artist),
                  trailing: ElevatedButton(child: const Text('Download'), onPressed: () => _downloadTrack(t)),
                )),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }
}
