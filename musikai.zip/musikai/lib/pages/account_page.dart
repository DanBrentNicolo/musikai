// lib/pages/account_page.dart
import 'package:flutter/material.dart';

// ✅ Account Page
class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 40),
            const CircleAvatar(
              radius: 48,
              backgroundColor: Colors.grey,
              child: Icon(Icons.person, size: 48),
            ),
            const SizedBox(height: 12),
            const Text(
              'BG User',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            const Text('bossgamer2005yt@gmail.com'),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text('Profile'),
              onTap: () {},
            ),
            ListTile(
              leading: const Icon(Icons.lock),
              title: const Text('Security'),
              onTap: () {},
            ),
            ListTile(
              leading: const Icon(Icons.notifications),
              title: const Text('Notifications'),
              onTap: () {},
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const SettingsPageWrapper(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.help),
              title: const Text('Help & Support'),
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

// ✅ Wrapper to connect to global theme toggle
class SettingsPageWrapper extends StatefulWidget {
  const SettingsPageWrapper({super.key});

  @override
  State<SettingsPageWrapper> createState() => _SettingsPageWrapperState();
}

class _SettingsPageWrapperState extends State<SettingsPageWrapper> {
  bool _isDark = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _isDark = Theme.of(context).brightness == Brightness.dark;
  }

  void _toggleTheme(bool value) {
    setState(() => _isDark = value);
    MyApp.of(context)?.changeTheme(_isDark ? ThemeMode.dark : ThemeMode.light);
  }

  @override
  Widget build(BuildContext context) {
    return SettingsPage(
      onThemeToggle: _toggleTheme,
      isDarkTheme: _isDark,
    );
  }
}

// ✅ Settings Page (combined)
class SettingsPage extends StatefulWidget {
  final Function(bool) onThemeToggle;
  final bool isDarkTheme;

  const SettingsPage({
    super.key,
    required this.onThemeToggle,
    required this.isDarkTheme,
  });

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late bool _darkMode;
  bool _notifications = true;
  bool _secureAccount = true;

  @override
  void initState() {
    super.initState();
    _darkMode = widget.isDarkTheme;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text("Dark Mode"),
            value: _darkMode,
            onChanged: (val) {
              setState(() => _darkMode = val);
              widget.onThemeToggle(val);
            },
            secondary: const Icon(Icons.brightness_6),
          ),
          const Divider(),
          SwitchListTile(
            title: const Text("Notifications"),
            value: _notifications,
            onChanged: (val) => setState(() => _notifications = val),
            secondary: const Icon(Icons.notifications),
          ),
          SwitchListTile(
            title: const Text("Account Security"),
            value: _secureAccount,
            onChanged: (val) => setState(() => _secureAccount = val),
            secondary: const Icon(Icons.lock),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text("App Version"),
            subtitle: Text("v1.0.0"),
          ),
          const ListTile(
            leading: Icon(Icons.help_outline),
            title: Text("Help & Support"),
          ),
          const ListTile(
            leading: Icon(Icons.policy),
            title: Text("Privacy Policy"),
          ),
        ],
      ),
    );
  }
}

// ✅ Wrap this around your MaterialApp in main.dart to enable theme switching
class MyApp extends StatefulWidget {
  final Widget child;

  const MyApp({super.key, required this.child});

  static _MyAppState? of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>();

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.light;

  void changeTheme(ThemeMode newMode) {
    setState(() {
      _themeMode = newMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      themeMode: _themeMode,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: widget.child,
    );
  }
}
