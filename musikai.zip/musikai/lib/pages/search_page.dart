// lib/pages/search_page.dart
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/player_manager.dart';
import '../services/full_player_page.dart'; // adjust path if yours differs

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> with SingleTickerProviderStateMixin {
  bool isListening = false;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      lowerBound: 0.95,
      upperBound: 1.05,
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _startDetection(PlayerManager pm) async {
    if (isListening) return;

    setState(() {
      isListening = true;
    });
    _pulseController.repeat(reverse: true);

    // Simulate listening detection (replace with actual logic)
    await Future.delayed(const Duration(seconds: 3));

    // example success/failure toggle; replace with real detection result
    final success = DateTime.now().second % 2 == 0;

    if (!success) {
      setState(() {
        isListening = false;
      });
      _pulseController.stop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ No song detected. Try again.')),
      );
      return;
    }

    // Create detected track (simulate)
    final detected = Track(
      id: 'detected_${Random().nextInt(100000)}',
      title: 'Detected Song',
      artist: 'Detected Artist',
      image: 'https://picsum.photos/seed/detect${Random().nextInt(999)}/400/400',
      source: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(Random().nextInt(10) + 1)}.mp3',
      isLocal: false,
    );

    // Auto-play and navigate to full player page
    await pm.setQueue([detected], startIndex: 0, playImmediately: true);

    // Stop listening UI
    if (mounted) {
      setState(() {
        isListening = false;
      });
      _pulseController.stop();

      // navigate to full player
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const FullPlayerPage()),
      );
    }
  }

  // Manual search screen push
  void _openManualSearch() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ManualSearchScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context);
    final size = MediaQuery.of(context).size;
    final logoSize = size.width * 0.26;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: isListening ? _pulseController : const AlwaysStoppedAnimation(1.0),
                  child: GestureDetector(
                    onTap: () => _startDetection(pm),
                    child: Container(
                      width: logoSize,
                      height: logoSize,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: Colors.black26, blurRadius: 10, spreadRadius: 2),
                        ],
                      ),
                      child: ClipOval(
                        child: Image.asset('assets/logo.png', fit: BoxFit.cover),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  isListening ? 'Listening...' : 'Tap to identify a song',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 40),
                GestureDetector(
                  onTap: _openManualSearch,
                  child: Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      shape: BoxShape.circle,
                      boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12, offset: Offset(0, 4))],
                    ),
                    child: const Icon(Icons.search_rounded, color: Colors.white, size: 36),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ManualSearchScreen extends StatefulWidget {
  const ManualSearchScreen({super.key});

  @override
  State<ManualSearchScreen> createState() => _ManualSearchScreenState();
}

class _ManualSearchScreenState extends State<ManualSearchScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Track> _results = [];

  List<Track> _recommendedTracks() {
    return List.generate(20, (i) {
      final idx = i + 1;
      return Track(
        id: 'rec$idx',
        title: 'Recommended Song $idx',
        artist: 'Artist $idx',
        image: 'https://picsum.photos/seed/rec$idx/300/300',
        source: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(idx % 16) + 1}.mp3',
        isLocal: false,
      );
    });
  }

  List<Track> _trendingTracks() {
    return List.generate(15, (i) {
      return Track(
        id: 'trend$i',
        title: 'Trending Song $i',
        artist: 'Top Artist $i',
        image: 'https://picsum.photos/seed/trend$i/300/300',
        source: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(i % 10) + 1}.mp3',
        isLocal: false,
      );
    });
  }

  List<Track> _newReleaseTracks() {
    return List.generate(12, (i) {
      return Track(
        id: 'new$i',
        title: 'New Release $i',
        artist: 'New Artist $i',
        image: 'https://picsum.photos/seed/new$i/300/300',
        source: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(i % 12) + 1}.mp3',
        isLocal: false,
      );
    });
  }

  List<Track> _getGlobalPool(PlayerManager pm) {
    // combine generated catalogs + recents + favorites
    final pool = <Track>[];
    pool.addAll(_recommendedTracks());
    pool.addAll(_trendingTracks());
    pool.addAll(_newReleaseTracks());
    pool.addAll(pm.recent);
    pool.addAll(pm.favorites);
    // de-duplicate by id
    final ids = <String>{};
    final unique = <Track>[];
    for (final t in pool) {
      if (!ids.contains(t.id)) {
        ids.add(t.id);
        unique.add(t);
      }
    }
    return unique;
  }

  void _searchTracks(PlayerManager pm, String query) {
    final q = query.trim().toLowerCase();
    final pool = _getGlobalPool(pm);
    if (q.isEmpty) {
      setState(() => _results = pool.take(30).toList());
      return;
    }
    final found = pool.where((t) {
      return t.title.toLowerCase().contains(q) || t.artist.toLowerCase().contains(q);
    }).toList();
    setState(() => _results = found);
  }

  @override
  void initState() {
    super.initState();
    _results = _trendingTracks();
  }

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context, listen: false);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Search'),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(30)),
              child: TextField(
                controller: _controller,
                onChanged: (value) => _searchTracks(pm, value),
                decoration: InputDecoration(
                  hintText: 'Search songs, artists...',
                  prefixIcon: const Icon(Icons.search),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _controller.clear();
                      _searchTracks(pm, '');
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: _results.isEmpty
                  ? const Center(child: Text('No results'))
                  : ListView.builder(
                      itemCount: _results.length,
                      itemBuilder: (context, i) {
                        final t = _results[i];
                        return ListTile(
                          contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                          leading: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(t.image, width: 60, height: 60, fit: BoxFit.cover),
                          ),
                          title: Text(t.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                          subtitle: Text(t.artist),
                          trailing: IconButton(
                            icon: const Icon(Icons.play_arrow_rounded, size: 32, color: Colors.black87),
                            onPressed: () async {
                              await pm.setQueue([t], startIndex: 0, playImmediately: true);
                              if (mounted) {
                                Navigator.push(context, MaterialPageRoute(builder: (_) => const FullPlayerPage()));
                              }
                            },
                          ),
                          onTap: () async {
                            await pm.setQueue([t], startIndex: 0, playImmediately: true);
                            if (mounted) {
                              Navigator.push(context, MaterialPageRoute(builder: (_) => const FullPlayerPage()));
                            }
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
