// lib/pages/home_page.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/player_manager.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  List<Track> _generateSamples(int start) {
    return List.generate(20, (i) {
      final idx = start + i;
      return Track(
        id: 's$idx',
        title: 'Sample Track $idx',
        artist: 'Artist $idx',
        image: 'https://picsum.photos/seed/cover$idx/300/300',
        source:
            'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${(idx % 16) + 1}.mp3',
        isLocal: false,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context);
    final recent = pm.recent;
    final recommended = _generateSamples(0);
    final trending = _generateSamples(30);
    final newReleases = _generateSamples(60);

    // shared horizontal section builder (with popup icon)
    Widget section(String title, List<Track> list) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              title,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: 210,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: list.length,
              itemBuilder: (context, index) {
                final t = list[index];
                return Container(
                  width: 160,
                  margin: const EdgeInsets.only(right: 14),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () async {
                        await pm.setQueue(list,
                            startIndex: index, playImmediately: true);
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(
                            alignment: Alignment.topRight,
                            children: [
                              Image.network(
                                t.image,
                                width: double.infinity,
                                height: 120,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                    height: 120, color: Colors.grey[300]),
                              ),
                              PopupMenuButton<String>(
                                icon: const Icon(Icons.more_vert,
                                    color: Colors.white),
                                onSelected: (value) {
                                  switch (value) {
                                    case 'fav':
                                      pm.toggleFavorite(t);
                                      final isFav = pm.isFavorite(t);
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                        content: Text(isFav
                                            ? '${t.title} added to Favorites'
                                            : '${t.title} removed from Favorites'),
                                      ));
                                      break;
                                    case 'playlist':
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                              content: Text(
                                                  '${t.title} added to Playlist')));
                                      break;
                                    case 'album':
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                              content: Text(
                                                  'Opening album of ${t.title}')));
                                      break;
                                    case 'artist':
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                              content: Text(
                                                  'Opening artist page for ${t.artist}')));
                                      break;
                                    case 'lyrics':
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                              content: Text(
                                                  'Viewing lyrics for ${t.title}')));
                                      break;
                                  }
                                },
                                itemBuilder: (context) => const [
                                  PopupMenuItem(
                                      value: 'fav',
                                      child: Text('Add to Favorites')),
                                  PopupMenuItem(
                                      value: 'playlist',
                                      child: Text('Add to Playlist')),
                                  PopupMenuItem(
                                      value: 'album',
                                      child: Text('Go to Album')),
                                  PopupMenuItem(
                                      value: 'artist',
                                      child: Text('Go to Artist')),
                                  PopupMenuItem(
                                      value: 'lyrics',
                                      child: Text('View Lyrics')),
                                ],
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  t.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  t.artist,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: Colors.grey, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      );
    }

    // Listen Again section now has popup icons too
    Widget listenAgainSection() {
      if (recent.isEmpty) return const SizedBox.shrink();
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Listen Again',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SizedBox(
            height: 150,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: recent.length,
              itemBuilder: (c, i) {
                final t = recent[i];
                return Container(
                  width: 130,
                  margin: const EdgeInsets.only(right: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          GestureDetector(
                            onTap: () => pm.playTrackDirect(t),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(t.image,
                                  width: 130,
                                  height: 90,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                      height: 90, color: Colors.grey[300])),
                            ),
                          ),
                          PopupMenuButton<String>(
                            icon: const Icon(Icons.more_vert,
                                color: Colors.white),
                            onSelected: (value) {
                              switch (value) {
                                case 'fav':
                                  pm.toggleFavorite(t);
                                  final isFav = pm.isFavorite(t);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(isFav
                                          ? '${t.title} added to Favorites'
                                          : '${t.title} removed from Favorites'),
                                    ),
                                  );
                                  break;
                                case 'playlist':
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            '${t.title} added to Playlist')),
                                  );
                                  break;
                                case 'album':
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            'Opening album of ${t.title}')),
                                  );
                                  break;
                                case 'artist':
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            'Opening artist page for ${t.artist}')),
                                  );
                                  break;
                                case 'lyrics':
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            'Viewing lyrics for ${t.title}')),
                                  );
                                  break;
                              }
                            },
                            itemBuilder: (context) => const [
                              PopupMenuItem(
                                  value: 'fav', child: Text('Add to Favorites')),
                              PopupMenuItem(
                                  value: 'playlist',
                                  child: Text('Add to Playlist')),
                              PopupMenuItem(
                                  value: 'album', child: Text('Go to Album')),
                              PopupMenuItem(
                                  value: 'artist', child: Text('Go to Artist')),
                              PopupMenuItem(
                                  value: 'lyrics', child: Text('View Lyrics')),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(t.title,
                          overflow: TextOverflow.ellipsis,
                          style:
                              const TextStyle(fontWeight: FontWeight.bold)),
                      Text(t.artist,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                    ],
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
        ],
      );
    }

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            listenAgainSection(),
            section('Recommended for you', recommended),
            section('Trending', trending),
            section('New Releases', newReleases),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }
}
