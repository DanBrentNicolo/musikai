// lib/services/player_manager.dart
import 'dart:convert';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Track {
  final String id;
  final String title;
  final String artist;
  final String image; // url or file://
  final String source; // url or file path
  final bool isLocal;

  Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.image,
    required this.source,
    this.isLocal = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': title == '' ? '' : artist,
        'image': image,
        'source': source,
        'isLocal': isLocal,
      };

  factory Track.fromJson(Map<String, dynamic> m) => Track(
        id: m['id'],
        title: m['title'],
        artist: m['artist'],
        image: m['image'],
        source: m['source'],
        isLocal: m['isLocal'] ?? false,
      );
}

class PlayerManager extends ChangeNotifier {
  // singleton
  static final PlayerManager _instance = PlayerManager._internal();
  factory PlayerManager() => _instance;
  PlayerManager._internal();

  final AudioPlayer _player = AudioPlayer();
  ConcatenatingAudioSource? _playlist;
  List<Track> _queue = [];
  Track? _current;
  List<Track> _recent = [];
  List<Track> _favorites = [];
  bool _shuffle = false;
  LoopMode _loopMode = LoopMode.off;

  // streams exposed
  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration> get bufferedPositionStream => _player.bufferedPositionStream;
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<int?> get currentIndexStream => _player.currentIndexStream;
  Stream<SequenceState?> get sequenceStateStream => _player.sequenceStateStream;
  Stream<bool> get playingStream => _player.playingStream;

  Track? get current => _current;
  List<Track> get queue => List.unmodifiable(_queue);
  List<Track> get recent => List.unmodifiable(_recent);
  List<Track> get favorites => List.unmodifiable(_favorites);
  bool get shuffle => _shuffle;
  LoopMode get loopMode => _loopMode;
  AudioPlayer get audioPlayer => _player;

  // --------------------------- INIT ---------------------------
  Future<void> init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());

    _player.playerStateStream.listen((_) => notifyListeners());
    _player.processingStateStream.listen((_) => notifyListeners());
    _player.currentIndexStream.listen((i) {
      if (i != null && _queue.isNotEmpty && i >= 0 && i < _queue.length) {
        _current = _queue[i];
        _addToRecent(_current!);
        notifyListeners();
      }
    });

    await _loadRecent();
    await _loadFavorites();
  }

  // --------------------------- FAVORITES ---------------------------
  Future<void> _loadFavorites() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString('favorite_tracks') ?? '[]';
    final arr = json.decode(raw) as List;
    _favorites =
        arr.map((e) => Track.fromJson(e as Map<String, dynamic>)).toList();
    notifyListeners();
  }

  Future<void> _saveFavorites() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(
        'favorite_tracks', json.encode(_favorites.map((t) => t.toJson()).toList()));
  }

  Future<void> toggleFavorite(Track track) async {
    final existing = _favorites.indexWhere((t) => t.id == track.id);
    if (existing >= 0) {
      _favorites.removeAt(existing);
    } else {
      _favorites.insert(0, track);
    }
    await _saveFavorites();
    notifyListeners();
  }

  bool isFavorite(Track track) => _favorites.any((t) => t.id == track.id);

  // --------------------------- RECENTS ---------------------------
  Future<void> _loadRecent() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString('recent_tracks') ?? '[]';
    final arr = json.decode(raw) as List;
    _recent =
        arr.map((e) => Track.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> _saveRecent() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(
        'recent_tracks', json.encode(_recent.map((t) => t.toJson()).toList()));
  }

  void _addToRecent(Track track) {
    _recent.removeWhere((t) => t.id == track.id);
    _recent.insert(0, track);
    if (_recent.length > 50) _recent = _recent.take(50).toList();
    _saveRecent();
  }

  // --------------------------- QUEUE / PLAYBACK ---------------------------
  Future<void> setQueue(List<Track> tracks,
      {int startIndex = 0, bool playImmediately = true}) async {
    _queue = List.from(tracks);

    final sources = tracks.map((t) {
      if (t.isLocal) {
        return AudioSource.uri(Uri.file(t.source), tag: t.toJson());
      } else {
        return AudioSource.uri(Uri.parse(t.source), tag: t.toJson());
      }
    }).toList();

    _playlist = ConcatenatingAudioSource(children: sources);
    await _player.setAudioSource(_playlist!, initialIndex: startIndex);
    _current = _queue[startIndex];
    _addToRecent(_current!);
    notifyListeners();

    if (playImmediately) await play();
  }

  Future<void> playTrackDirect(Track track) async {
    await setQueue([track], startIndex: 0, playImmediately: true);
  }

  Future<void> play() => _player.play();

  Future<void> pause() => _player.pause();

  /// STOP: stops playback, clears current track & playlist (so mini-player hides)
  Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
    _current = null;
    _queue.clear();
    if (_playlist != null) {
      try {
        await _playlist!.clear();
      } catch (_) {}
      _playlist = null;
    }
    notifyListeners();
  }

  Future<void> seek(Duration position) => _player.seek(position);
  Future<void> next() => _player.seekToNext();
  Future<void> previous() => _player.seekToPrevious();

  Future<void> toggleShuffle() async {
    _shuffle = !_shuffle;
    await _player.setShuffleModeEnabled(_shuffle);
    notifyListeners();
  }

  Future<void> setLoopMode(LoopMode mode) async {
    _loopMode = mode;
    await _player.setLoopMode(mode);
    notifyListeners();
  }

  // helper to set a combined state (used by UI cycle)
  Future<void> setShuffleAndLoop({required bool shuffle, required LoopMode loop}) async {
    _shuffle = shuffle;
    _loopMode = loop;
    await _player.setShuffleModeEnabled(_shuffle);
    await _player.setLoopMode(loop);
    notifyListeners();
  }

  Future<void> addToQueue(Track t) async {
    _queue.add(t);
    if (_playlist != null) {
      final src = t.isLocal
          ? AudioSource.uri(Uri.file(t.source), tag: t.toJson())
          : AudioSource.uri(Uri.parse(t.source), tag: t.toJson());
      await _playlist!.add(src);
    }
    notifyListeners();
  }

  Future<void> clearQueue() async {
    _queue.clear();
    if (_playlist != null) {
      await _playlist!.clear();
      _playlist = null;
    }
    notifyListeners();
  }

  void disposeManager() {
    _player.dispose();
  }
}
