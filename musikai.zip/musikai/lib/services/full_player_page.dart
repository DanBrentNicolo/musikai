// lib/pages/full_player_page.dart
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../services/player_manager.dart';

class FullPlayerPage extends StatelessWidget {
  const FullPlayerPage({super.key});

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context);
    final current = pm.current;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
        title: const Text("Now Playing"),
        centerTitle: true,
        actions: [
          // optional extra buttons can be added here
        ],
      ),
      body: current == null
          ? const Center(child: Text("No track is currently playing"))
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                child: Column(
                  children: [
                    // Album Art responsive
                    LayoutBuilder(builder: (context, constraints) {
                      final size = constraints.maxWidth < 360 ? constraints.maxWidth * 0.8 : 300.0;
                      return ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          current.image,
                          width: size,
                          height: size,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(width: size, height: size, color: Colors.grey[300]),
                        ),
                      );
                    }),
                    const SizedBox(height: 18),
                    Text(
                      current.title,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(current.artist, style: const TextStyle(color: Colors.grey, fontSize: 16)),
                    const SizedBox(height: 18),

                    // Progress + slider
                    StreamBuilder<Duration?>(stream: pm.durationStream, builder: (context, snapDur) {
                      final total = snapDur.data ?? Duration.zero;
                      return StreamBuilder<Duration>(stream: pm.positionStream, builder: (context, snapPos) {
                        final pos = snapPos.data ?? Duration.zero;
                        final maxMs = total.inMilliseconds > 0 ? total.inMilliseconds.toDouble() : 1.0;
                        final value = maxMs <= 0 ? 0.0 : pos.inMilliseconds.clamp(0, total.inMilliseconds).toDouble();
                        return Column(
                          children: [
                            Slider(
                              value: (maxMs <= 0) ? 0.0 : (value / maxMs).clamp(0.0, 1.0),
                              onChanged: (v) {
                                if (total.inMilliseconds > 0) {
                                  pm.seek(total * v);
                                }
                              },
                            ),
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                              Text(_format(pos), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                              Text(_format(total), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                            ]),
                          ],
                        );
                      });
                    }),

                    const SizedBox(height: 12),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton(icon: const Icon(Icons.skip_previous), iconSize: 40, onPressed: pm.previous),
                      const SizedBox(width: 12),
                      StreamBuilder<PlayerState>(stream: pm.playerStateStream, builder: (context, snapshot) {
                        final state = snapshot.data;
                        final playing = state?.playing ?? false;
                        return IconButton(
                          icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_filled),
                          iconSize: 64,
                          onPressed: () => playing ? pm.pause() : pm.play(),
                        );
                      }),
                      const SizedBox(width: 12),
                      IconButton(icon: const Icon(Icons.skip_next), iconSize: 40, onPressed: pm.next),
                    ]),
                    const SizedBox(height: 18),

                    // Combined cycle button + separate shuffle/loop status shown
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton(
                        icon: Icon(
                          // visual: show loop/shuffle combined state
                          pm.shuffle
                              ? Icons.shuffle_on
                              : (pm.loopMode == LoopMode.one ? Icons.repeat_one : (pm.loopMode == LoopMode.all ? Icons.repeat : Icons.repeat_outlined)),
                          color: (pm.shuffle || pm.loopMode != LoopMode.off) ? Colors.blue : Colors.grey,
                        ),
                        onPressed: () async {
                          // cycle: Off -> Repeat All -> Repeat One -> Shuffle -> Off
                          if (!pm.shuffle && pm.loopMode == LoopMode.off) {
                            await pm.setShuffleAndLoop(shuffle: false, loop: LoopMode.all);
                          } else if (!pm.shuffle && pm.loopMode == LoopMode.all) {
                            await pm.setShuffleAndLoop(shuffle: false, loop: LoopMode.one);
                          } else if (!pm.shuffle && pm.loopMode == LoopMode.one) {
                            // move to shuffle on
                            await pm.setShuffleAndLoop(shuffle: true, loop: LoopMode.off);
                          } else {
                            // currently shuffle on -> reset all off
                            await pm.setShuffleAndLoop(shuffle: false, loop: LoopMode.off);
                          }
                        },
                      ),
                      const SizedBox(width: 20),
                      // show textual state
                      Text(
                        pm.shuffle
                            ? 'Shuffle'
                            : (pm.loopMode == LoopMode.one ? 'Repeat One' : (pm.loopMode == LoopMode.all ? 'Repeat All' : 'Normal')),
                        style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                      ),
                    ]),
                  ],
                ),
              ),
            ),
    );
  }

  String _format(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return "$m:$s";
  }
}
