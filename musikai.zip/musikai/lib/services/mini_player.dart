// lib/widgets/mini_player.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/player_manager.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context);
    final track = pm.current;
    if (track == null) return const SizedBox.shrink();

    return Container(
      color: Colors.black.withOpacity(0.85),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              track.image,
              width: 48,
              height: 48,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(width: 48, height: 48, color: Colors.grey[700]),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "${track.title} • ${track.artist}",
              style: const TextStyle(color: Colors.white),
              overflow: TextOverflow.ellipsis,
            ),
          ),

          // play/pause (listens to playing stream)
          StreamBuilder<bool>(
            stream: pm.playingStream,
            builder: (context, snapshot) {
              final playing = snapshot.data ?? false;
              return IconButton(
                icon: Icon(playing ? Icons.pause : Icons.play_arrow, color: Colors.white),
                onPressed: playing ? pm.pause : pm.play,
              );
            },
          ),

          // X stop button
          IconButton(
            icon: const Icon(Icons.close, color: Colors.redAccent),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  backgroundColor: Colors.grey[900],
                  title: const Text("Stop Music?", style: TextStyle(color: Colors.white)),
                  content: const Text(
                    "Are you sure you want to stop the current track?",
                    style: TextStyle(color: Colors.white70),
                  ),
                  actions: [
                    TextButton(
                      child: const Text("Cancel", style: TextStyle(color: Colors.white70)),
                      onPressed: () => Navigator.pop(context, false),
                    ),
                    TextButton(
                      child: const Text("Stop", style: TextStyle(color: Colors.redAccent)),
                      onPressed: () => Navigator.pop(context, true),
                    ),
                  ],
                ),
              );

              if (confirm == true) {
                await pm.stop();
              }
            },
          ),
        ],
      ),
    );
  }
}
