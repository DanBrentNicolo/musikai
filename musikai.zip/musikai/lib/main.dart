// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/player_manager.dart';
import 'package:just_audio/just_audio.dart';
import 'pages/home_page.dart';
import 'pages/search_page.dart';
import 'pages/library_page.dart';
import 'pages/account_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final pm = PlayerManager();
  await pm.init();
  runApp(
    ChangeNotifierProvider<PlayerManager>.value(
      value: pm,
      child: const MyApp(),
    ),
  );
}

class ThemeNotifier extends ChangeNotifier {
  bool _isDark = false;
  bool get isDark => _isDark;

  void toggleTheme(bool val) {
    _isDark = val;
    notifyListeners();
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.system;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MusikAI',
      theme: ThemeData.light(useMaterial3: true),
      darkTheme: ThemeData.dark(useMaterial3: true),
      themeMode: _themeMode,
      home: const MainPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final PageController _pageController = PageController();
  int _index = 0;

  final pages = const [
    HomePage(),
    SearchPage(),
    LibraryPage(),
    AccountPage(),
  ];

  void _onItemTapped(int i) {
    setState(() => _index = i);
    _pageController.jumpToPage(i);
  }

  @override
  Widget build(BuildContext context) {
    final pm = Provider.of<PlayerManager>(context);
    final theme = Theme.of(context);

    final bool hasMini = pm.current != null;
    final double miniHeight = hasMini ? 72.0 : 0.0;
    const double navHeight = 56.0;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: miniHeight + navHeight),
            child: PageView(
              controller: _pageController,
              physics: const NeverScrollableScrollPhysics(),
              onPageChanged: (i) => setState(() => _index = i),
              children: pages,
            ),
          ),

          // 🎵 Mini-player with close (X) button
          Align(
            alignment: Alignment.bottomCenter,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (hasMini)
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => FullPlayerPage()),
                    ),
                    child: Container(
                      color: theme.colorScheme.surfaceContainerHighest,
                      height: miniHeight,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: Image.network(
                              pm.current!.image,
                              width: 52,
                              height: 52,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                width: 52,
                                height: 52,
                                color: Colors.grey,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  pm.current!.title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  pm.current!.artist,
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: Icon(pm.audioPlayer.playing
                                ? Icons.pause
                                : Icons.play_arrow),
                            onPressed: () {
                              if (pm.audioPlayer.playing) {
                                pm.pause();
                              } else {
                                pm.play();
                              }
                            },
                          ),
                          // ❌ X button to stop playback
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () {
                              pm.stop(); // stops audio completely
                            },
                          ),
                        ],
                      ),
                    ),
                  ),

                // BottomNavigationBar
                SafeArea(
                  top: false,
                  child: BottomNavigationBar(
                    type: BottomNavigationBarType.fixed,
                    currentIndex: _index,
                    onTap: _onItemTapped,
                    selectedItemColor: Colors.blueAccent,
                    unselectedItemColor: Colors.grey,
                    backgroundColor: theme.colorScheme.surface,
                    items: const [
                      BottomNavigationBarItem(
                          icon: Icon(Icons.home), label: 'Home'),
                      BottomNavigationBarItem(
                          icon: Icon(Icons.search), label: 'Search'),
                      BottomNavigationBarItem(
                          icon: Icon(Icons.library_music), label: 'Library'),
                      BottomNavigationBarItem(
                          icon: Icon(Icons.person), label: 'Account'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// 🎧 Full Player Page — now consistent with back button and spinner control
class FullPlayerPage extends StatefulWidget {
  FullPlayerPage({super.key});
  @override
  State<FullPlayerPage> createState() => _FullPlayerPageState();
}

class _FullPlayerPageState extends State<FullPlayerPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _rotationController;
  late final PlayerManager pm;

  @override
  void initState() {
    super.initState();
    pm = Provider.of<PlayerManager>(context, listen: false);
    _rotationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 12));

    // Rotate CD only while playing
    pm.playerStateStream.listen((state) {
      if (state.playing) {
        if (!_rotationController.isAnimating) _rotationController.repeat();
      } else {
        if (_rotationController.isAnimating) _rotationController.stop();
      }
    });
  }

  @override
  void dispose() {
    _rotationController.dispose();
    super.dispose();
  }

  String _format(Duration d) {
    final mm = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final ss = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$mm:$ss';
  }

  @override
  Widget build(BuildContext context) {
    final pmLocal = Provider.of<PlayerManager>(context);
    final track = pmLocal.current;

    return Scaffold(
      appBar: AppBar(
        title: Text(track?.title ?? 'Player'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            if (track != null)
              RotationTransition(
                turns: _rotationController,
                child: ClipOval(
                  child: Image.network(
                    track.image,
                    width: 300,
                    height: 300,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            const SizedBox(height: 20),
            Text(track?.title ?? '-',
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(track?.artist ?? '-',
                style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 20),

            StreamBuilder<Duration?>(
              stream: pmLocal.durationStream,
              builder: (context, snapDur) {
                final total = snapDur.data ?? Duration.zero;
                return StreamBuilder<Duration?>(
                  stream: pmLocal.positionStream,
                  builder: (context, snapPos) {
                    final pos = snapPos.data ?? Duration.zero;
                    return Column(
                      children: [
                        Slider(
                          value: pos.inMilliseconds
                              .clamp(0, total.inMilliseconds)
                              .toDouble(),
                          max: total.inMilliseconds > 0
                              ? total.inMilliseconds.toDouble()
                              : 1.0,
                          onChanged: (v) => pmLocal.seek(
                              Duration(milliseconds: v.toInt())),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_format(pos)),
                            Text(_format(total))
                          ],
                        )
                      ],
                    );
                  },
                );
              },
            ),

            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                    icon: const Icon(Icons.skip_previous),
                    iconSize: 40,
                    onPressed: () => pmLocal.previous()),
                const SizedBox(width: 12),
                StreamBuilder<PlayerState>(
                  stream: pmLocal.playerStateStream,
                  builder: (context, s) {
                    final playing = s.data?.playing ?? false;
                    return IconButton(
                      icon: Icon(playing
                          ? Icons.pause_circle_filled
                          : Icons.play_circle_filled),
                      iconSize: 64,
                      onPressed: () =>
                          playing ? pmLocal.pause() : pmLocal.play(),
                    );
                  },
                ),
                const SizedBox(width: 12),
                IconButton(
                    icon: const Icon(Icons.skip_next),
                    iconSize: 40,
                    onPressed: () => pmLocal.next()),
              ],
            ),

            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(pmLocal.shuffle
                      ? Icons.shuffle_on
                      : Icons.shuffle),
                  onPressed: () => pmLocal.toggleShuffle(),
                ),
                const SizedBox(width: 20),
                PopupMenuButton<LoopMode>(
                  initialValue: pmLocal.loopMode,
                  onSelected: (m) => pmLocal.setLoopMode(m),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: LoopMode.off, child: Text('No repeat')),
                    PopupMenuItem(value: LoopMode.one, child: Text('Repeat one')),
                    PopupMenuItem(value: LoopMode.all, child: Text('Repeat all')),
                  ],
                  child: Icon(pmLocal.loopMode == LoopMode.off
                      ? Icons.repeat
                      : Icons.repeat_on),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
